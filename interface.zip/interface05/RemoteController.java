package edu.java.interface05;

public interface RemoteController {
	// public abstract 생략 가능
	void turnOn();
	void turnOff();
}
