package edu.java.interface06;

public interface Menu {
	int QUIT = 0; // 종료
	int INSERT = 1; // 등록
	int SELECT_ALL = 2; // 전체 검색
	int SELECT_BY_INDEX = 3; // 상세 검색
	int UPDATE = 4; // 수정
}
